<?php
require_once 'koneksi.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header("Location: login.php");
    exit();
}

function e($value) {
    return htmlspecialchars((string)$value, ENT_QUOTES, 'UTF-8');
}

if (isset($_POST['simpan'])) {
    $id = $_POST['id'];
    $nama = mysqli_real_escape_string($koneksi, $_POST['nama']);
    $deskripsi = mysqli_real_escape_string($koneksi, $_POST['deskripsi']);
    $status_aktif = isset($_POST['status_aktif']) ? 1 : 0;

    if ($id) {
        $id = (int)$id;
        mysqli_query($koneksi, "UPDATE t_pelanggaran_kategori
            SET nama='$nama', deskripsi='$deskripsi',
            status_aktif='$status_aktif' WHERE id='$id'");
    } else {
        mysqli_query($koneksi, "INSERT INTO t_pelanggaran_kategori
            (nama, deskripsi, status_aktif)
            VALUES ('$nama', '$deskripsi', '$status_aktif')");
    }

    header("Location: kelola_kategori_pelanggaran.php");
    exit();
}

if (isset($_GET['hapus'])) {
    $id = (int)$_GET['hapus'];
    mysqli_query($koneksi, "DELETE FROM t_pelanggaran_kategori WHERE id='$id'");
    header("Location: kelola_kategori_pelanggaran.php");
    exit();
}

$edit = ['id'=>'', 'nama'=>'', 'deskripsi'=>'', 'status_aktif'=>1];
$isEdit = false;

if (isset($_GET['edit'])) {
    $id = (int)$_GET['edit'];
    $resultEdit = mysqli_query($koneksi,
        "SELECT * FROM t_pelanggaran_kategori WHERE id='$id'");
    if ($resultEdit && mysqli_num_rows($resultEdit) > 0) {
        $edit = mysqli_fetch_assoc($resultEdit);
        $isEdit = true;
    }
}

$data = mysqli_query($koneksi, "SELECT * FROM t_pelanggaran_kategori");
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Kelola Kategori Pelanggaran</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.datatables.net/2.1.8/css/dataTables.dataTables.min.css" rel="stylesheet">

    <style>
        body {
            background-color: #f8f9fa;
            overflow: hidden;
        }
        .sidebar {
            min-height: 100vh;
            background: #212529;
            color: #fff;
            position: fixed;
            width: 250px;
            top: 0;
            left: 0;
            overflow-y: auto;
            z-index: 1000;
        }
        .sidebar a {
            color: #adb5bd;
            text-decoration: none;
            display: block;
            padding: 10px 20px;
        }
        .sidebar a:hover, .sidebar a.active {
            color: #fff;
            background: #0d6efd;
        }
        .main-content {
            margin-left: 250px;
            height: 100vh;
            overflow-y: auto;
            padding: 20px;
        }
        .table th, .table td {
            vertical-align: middle;
        }
        @media (max-width: 768px) {
            .sidebar {
                width: 180px;
            }
            .main-content {
                margin-left: 180px;
                padding: 12px;
            }
        }
    </style>
</head>
<body>

<!-- SIDEBAR -->
<div class="sidebar d-flex flex-column p-3">
    <h4 class="text-white mb-4">Pelanggaran Siswa</h4>
    <ul class="nav nav-pills flex-column mb-auto">
        <li class="nav-item mb-1"><a href="dashboard.php">Dashboard</a></li>
        <li class="nav-item mb-1"><a href="kelola_guru.php">Kelola Guru</a></li>
        <li class="nav-item mb-1"><a href="kelola_siswa.php">Kelola Siswa</a></li>
        <li class="nav-item mb-1"><a href="kelola_kelas.php">Kelola Kelas</a></li>
        <li class="nav-item mb-1"><a href="kelola_tahun_ajaran.php">Kelola Tahun Ajaran</a></li>
        <li class="nav-item mb-1"><a href="penempatan_siswa.php">Penempatan Siswa</a></li>
        <li class="nav-item mb-1"><a href="kelola_wali_kelas.php">Kelola Wali Kelas</a></li>
        <li class="nav-item mb-1"><a href="kelola_kategori_pelanggaran.php" class="active">Kelola Kategori Pelanggaran</a></li>
        <li class="nav-item mb-1"><a href="kelola_jenis_pelanggaran.php">Kelola Jenis Pelanggaran</a></li>
        <li class="nav-item mb-1"><a href="laporan.php">Laporan</a></li>
        <li class="nav-item mb-1"><a href="about_me.php">About Me</a></li>
    </ul>
    <hr>
    <a href="logout.php" class="text-danger">Logout</a>
</div>

<div class="main-content">
    <h2>Kelola Kategori Pelanggaran</h2>
    <hr>

    <!-- MODAL FORM (TAMBAH / EDIT) -->
    <div class="modal fade" id="modalKategori" tabindex="-1" aria-labelledby="modalKategoriLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <form method="POST">
                    <div class="modal-header">
                        <h5 class="modal-title" id="modalKategoriLabel"><?= $isEdit ? 'Edit Kategori Pelanggaran' : 'Tambah Kategori Pelanggaran'; ?></h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <input type="hidden" name="id" value="<?= e($edit['id']); ?>">

                        <div class="mb-3">
                            <label class="form-label">Nama Kategori:</label>
                            <input type="text" name="nama" class="form-control"
                                   value="<?= e($edit['nama']); ?>" required>
                        </div>

                        <div class="mb-3">
                            <label class="form-label">Deskripsi:</label>
                            <textarea name="deskripsi" class="form-control"
                                      rows="3"><?= e($edit['deskripsi']); ?></textarea>
                        </div>

                        <div class="form-check mb-3">
                            <input class="form-check-input" type="checkbox"
                                   name="status_aktif" id="status_aktif" value="1"
                                   <?= $edit['status_aktif'] == 1 ? 'checked' : ''; ?>>
                            <label class="form-check-label" for="status_aktif">
                                Status Aktif
                            </label>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <?php if ($isEdit): ?>
                            <a href="kelola_kategori_pelanggaran.php" class="btn btn-secondary">Batal</a>
                        <?php else: ?>
                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Tutup</button>
                        <?php endif; ?>
                        <button type="submit" name="simpan" class="btn btn-primary">Simpan</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- HEADER TABEL & TOMBOL TAMBAH DI SEBELAH KANAN -->
    <div class="d-flex justify-content-between align-items-center mb-3">
        <h5 class="mb-0">Data Kategori Pelanggaran</h5>
        <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#modalKategori">
            + Tambah Kategori Pelanggaran
        </button>
    </div>

    <!-- TABEL DATA -->
    <div class="card shadow-sm mb-4">
        <div class="card-body">
            <div class="table-responsive">
                <table id="tabelKategori" class="table table-bordered table-striped align-middle">
                    <thead class="table-dark">
                        <tr>
                            <th>No</th>
                            <th>Nama Kategori</th>
                            <th>Deskripsi</th>
                            <th>Status</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php $no = 1; while ($r = mysqli_fetch_assoc($data)): ?>
                        <tr>
                            <td><?= $no++; ?></td>
                            <td><?= e($r['nama']); ?></td>
                            <td><?= $r['deskripsi'] ? e($r['deskripsi']) : '-'; ?></td>
                            <td>
                                <?php if ($r['status_aktif'] == 1): ?>
                                    <span class="badge bg-success">Aktif</span>
                                <?php else: ?>
                                    <span class="badge bg-secondary">Tidak Aktif</span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <a href="kelola_kategori_pelanggaran.php?edit=<?= (int)$r['id']; ?>"
                                   class="btn btn-sm btn-warning">Edit</a>
                                <a href="kelola_kategori_pelanggaran.php?hapus=<?= (int)$r['id']; ?>"
                                   class="btn btn-sm btn-danger"
                                   onclick="return confirm('Yakin ingin menghapus kategori ini?')">
                                    Hapus
                                </a>
                            </td>
                        </tr>
                    <?php endwhile; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://cdn.datatables.net/2.1.8/js/dataTables.min.js"></script>
<script>
$(document).ready(function () {
    // Inisialisasi DataTables
    new DataTable('#tabelKategori', {
        pageLength: 10,
        lengthMenu: [5, 10, 25, 50],
        columnDefs: [
            { orderable: false, searchable: false, targets: [0, 4] }
        ],
        language: {
            search: "Cari:",
            lengthMenu: "Tampilkan 10 data",
            info: "Menampilkan _START_ sampai _END_ dari _TOTAL_ data",
            infoEmpty: "Tidak ada data",
            zeroRecords: "Data tidak ditemukan",
            emptyTable: "Belum ada kategori pelanggaran",
        
    });

    // Jika sedang dalam mode edit, otomatis buka modalnya
    <?php if ($isEdit): ?>
        var myModal = new bootstrap.Modal(document.getElementById('modalKategori'));
        myModal.show();
    <?php endif; ?>
});
</script>

</body>
</html>